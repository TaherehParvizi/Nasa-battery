import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np
import pandas as pd
import torch
import torch.nn.functional as F

def visualize_attention_weights(model, x_sample, feature_names=None):
    """Visualize attention weights for a sample"""
    if feature_names is None:
        feature_names = [f's_{i}' for i in range(15)]
    
    model.eval()
    with torch.no_grad():
        # Forward pass to get attention weights
        batch_size = x_sample.size(0)
        x = x_sample.unsqueeze(1)  # Add channel dimension
        
        # Pass through CNN layers
        x = F.relu(model.batch_norm1(model.conv1(x)))
        x = F.relu(model.batch_norm2(model.conv2(x)))
        x = F.relu(model.batch_norm3(model.conv3(x)))
        
        # Transpose for attention
        x = x.transpose(1, 2)
        
        # Get attention weights
        _, attention_weights = model.attention(x)
        
        # Average attention weights across batch
        avg_attention = attention_weights.mean(dim=0).cpu().numpy()
        
        # Create visualization
        plt.figure(figsize=(12, 6))
        
        # Attention weights heatmap
        plt.subplot(1, 2, 1)
        sns.heatmap(avg_attention.reshape(1, -1), 
                   xticklabels=feature_names, 
                   yticklabels=['Attention'],
                   cmap='viridis', 
                   annot=True, 
                   fmt='.3f',
                   cbar_kws={'label': 'Attention Weight'})
        plt.title('Feature Attention Weights')
        plt.xlabel('Battery Signature Features')
        
        # Attention weights bar plot
        plt.subplot(1, 2, 2)
        bars = plt.bar(range(len(avg_attention)), avg_attention, 
                      color=plt.cm.viridis(avg_attention / avg_attention.max()))
        plt.xlabel('Feature Index')
        plt.ylabel('Attention Weight')
        plt.title('Feature Importance via Attention')
        plt.xticks(range(len(feature_names)), feature_names, rotation=45)
        
        # Add value labels on bars
        for i, bar in enumerate(bars):
            height = bar.get_height()
            plt.text(bar.get_x() + bar.get_width()/2., height,
                    f'{height:.3f}', ha='center', va='bottom')
        
        plt.tight_layout()
        plt.savefig('./datacsv/attention_visualization.png', dpi=300, bbox_inches='tight')
        plt.show()
        
        return avg_attention

def plot_model_comparison(results_df):
    """Create comparison plots for different models"""
    fig, axes = plt.subplots(2, 2, figsize=(15, 12))
    
    # Concordance Index comparison
    models = results_df['Model'].unique()
    ci_means = [results_df[results_df['Model'] == model]['CI'].mean() for model in models]
    ci_stds = [results_df[results_df['Model'] == model]['CI'].std() for model in models]
    
    axes[0, 0].bar(models, ci_means, yerr=ci_stds, capsize=5, 
                   color=['#1f77b4', '#ff7f0e', '#2ca02c', '#d62728', '#9467bd'][:len(models)])
    axes[0, 0].set_title('Concordance Index Comparison')
    axes[0, 0].set_ylabel('Concordance Index')
    axes[0, 0].tick_params(axis='x', rotation=45)
    axes[0, 0].grid(True, alpha=0.3)
    
    # IBS comparison
    ibs_means = [results_df[results_df['Model'] == model]['IBS'].mean() for model in models]
    ibs_stds = [results_df[results_df['Model'] == model]['IBS'].std() for model in models]
    
    axes[0, 1].bar(models, ibs_means, yerr=ibs_stds, capsize=5,
                   color=['#1f77b4', '#ff7f0e', '#2ca02c', '#d62728', '#9467bd'][:len(models)])
    axes[0, 1].set_title('Integrated Brier Score Comparison (Lower is Better)')
    axes[0, 1].set_ylabel('Integrated Brier Score')
    axes[0, 1].tick_params(axis='x', rotation=45)
    axes[0, 1].grid(True, alpha=0.3)
    
    # AUC comparison
    auc_means = [results_df[results_df['Model'] == model]['AUC'].mean() for model in models]
    auc_stds = [results_df[results_df['Model'] == model]['AUC'].std() for model in models]
    
    axes[1, 0].bar(models, auc_means, yerr=auc_stds, capsize=5,
                   color=['#1f77b4', '#ff7f0e', '#2ca02c', '#d62728', '#9467bd'][:len(models)])
    axes[1, 0].set_title('Area Under Curve Comparison')
    axes[1, 0].set_ylabel('AUC Score')
    axes[1, 0].tick_params(axis='x', rotation=45)
    axes[1, 0].grid(True, alpha=0.3)
    
    # Box plot for CI distribution
    ci_data = []
    model_labels = []
    for model in models:
        model_data = results_df[results_df['Model'] == model]['CI'].values
        ci_data.extend(model_data)
        model_labels.extend([model] * len(model_data))
    
    ci_df = pd.DataFrame({'Model': model_labels, 'CI': ci_data})
    sns.boxplot(data=ci_df, x='Model', y='CI', ax=axes[1, 1])
    axes[1, 1].set_title('Concordance Index Distribution')
    axes[1, 1].tick_params(axis='x', rotation=45)
    axes[1, 1].grid(True, alpha=0.3)
    
    plt.tight_layout()
    plt.savefig('./datacsv/model_comparison.png', dpi=300, bbox_inches='tight')
    plt.show()

def plot_training_curves(train_losses, val_losses, epochs):
    """Plot training and validation curves"""
    plt.figure(figsize=(10, 6))
    
    plt.subplot(1, 2, 1)
    plt.plot(epochs, train_losses, 'b-', label='Training Loss', linewidth=2)
    plt.plot(epochs, val_losses, 'r-', label='Validation Loss', linewidth=2)
    plt.xlabel('Epoch')
    plt.ylabel('Loss')
    plt.title('Training and Validation Loss')
    plt.legend()
    plt.grid(True, alpha=0.3)
    
    plt.subplot(1, 2, 2)
    plt.plot(epochs, np.array(train_losses) - np.array(val_losses), 'g-', linewidth=2)
    plt.xlabel('Epoch')
    plt.ylabel('Training - Validation Loss')
    plt.title('Overfitting Monitor')
    plt.axhline(y=0, color='k', linestyle='--', alpha=0.5)
    plt.grid(True, alpha=0.3)
    
    plt.tight_layout()
    plt.savefig('./datacsv/training_curves.png', dpi=300, bbox_inches='tight')
    plt.show()

def create_feature_importance_analysis():
    """Create a comprehensive feature importance analysis"""
    # Simulate feature importance data for demonstration
    feature_names = [f's_{i}' for i in range(15)]
    
    # Simulated attention weights from multiple samples
    np.random.seed(42)
    attention_data = np.random.dirichlet(np.ones(15), size=100)  # 100 samples
    
    # Calculate statistics
    mean_attention = attention_data.mean(axis=0)
    std_attention = attention_data.std(axis=0)
    
    # Create comprehensive visualization
    fig, axes = plt.subplots(2, 2, figsize=(16, 12))
    
    # 1. Mean attention weights with error bars
    axes[0, 0].bar(range(15), mean_attention, yerr=std_attention, 
                   capsize=5, color='skyblue', alpha=0.7)
    axes[0, 0].set_xlabel('Battery Signature Features')
    axes[0, 0].set_ylabel('Mean Attention Weight')
    axes[0, 0].set_title('Average Feature Importance (with std)')
    axes[0, 0].set_xticks(range(15))
    axes[0, 0].set_xticklabels(feature_names, rotation=45)
    axes[0, 0].grid(True, alpha=0.3)
    
    # 2. Attention weight distribution heatmap
    im = axes[0, 1].imshow(attention_data.T, aspect='auto', cmap='viridis')
    axes[0, 1].set_xlabel('Sample Index')
    axes[0, 1].set_ylabel('Feature Index')
    axes[0, 1].set_title('Attention Weights Across All Samples')
    axes[0, 1].set_yticks(range(15))
    axes[0, 1].set_yticklabels(feature_names)
    plt.colorbar(im, ax=axes[0, 1], label='Attention Weight')
    
    # 3. Feature ranking
    feature_ranking = np.argsort(mean_attention)[::-1]
    ranked_names = [feature_names[i] for i in feature_ranking]
    ranked_weights = mean_attention[feature_ranking]
    
    colors = plt.cm.RdYlBu_r(np.linspace(0, 1, 15))
    bars = axes[1, 0].barh(range(15), ranked_weights, color=colors)
    axes[1, 0].set_yticks(range(15))
    axes[1, 0].set_yticklabels(ranked_names)
    axes[1, 0].set_xlabel('Attention Weight')
    axes[1, 0].set_title('Features Ranked by Importance')
    axes[1, 0].grid(True, alpha=0.3)
    
    # Add value labels
    for i, bar in enumerate(bars):
        width = bar.get_width()
        axes[1, 0].text(width + 0.001, bar.get_y() + bar.get_height()/2,
                       f'{width:.3f}', ha='left', va='center')
    
    # 4. Correlation analysis (simulated)
    correlation_matrix = np.corrcoef(attention_data.T)
    im = axes[1, 1].imshow(correlation_matrix, cmap='coolwarm', vmin=-1, vmax=1)
    axes[1, 1].set_xlabel('Feature Index')
    axes[1, 1].set_ylabel('Feature Index')
    axes[1, 1].set_title('Feature Attention Correlation Matrix')
    axes[1, 1].set_xticks(range(15))
    axes[1, 1].set_xticklabels(feature_names, rotation=45)
    axes[1, 1].set_yticks(range(15))
    axes[1, 1].set_yticklabels(feature_names)
    plt.colorbar(im, ax=axes[1, 1], label='Correlation')
    
    plt.tight_layout()
    plt.savefig('./datacsv/feature_importance_analysis.png', dpi=300, bbox_inches='tight')
    plt.show()
    
    # Save feature importance data
    importance_df = pd.DataFrame({
        'Feature': feature_names,
        'Mean_Attention': mean_attention,
        'Std_Attention': std_attention,
        'Rank': range(1, 16)
    })
    importance_df = importance_df.sort_values('Mean_Attention', ascending=False).reset_index(drop=True)
    importance_df['Rank'] = range(1, 16)
    
    importance_df.to_csv('./datacsv/feature_importance_ranking.csv', index=False)
    print("Feature importance analysis saved to: ./datacsv/feature_importance_ranking.csv")
    
    return importance_df

if __name__ == "__main__":
    # Create feature importance analysis
    importance_results = create_feature_importance_analysis()
    print("\\nTop 5 Most Important Features:")
    print(importance_results.head()[['Feature', 'Mean_Attention', 'Rank']])